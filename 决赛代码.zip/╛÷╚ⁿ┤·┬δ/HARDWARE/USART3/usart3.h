#ifndef __USART3_H 
#define __USART3_H  
#include "sys.h" 

void USART3_Init(u32 My_BaudRate);
#endif